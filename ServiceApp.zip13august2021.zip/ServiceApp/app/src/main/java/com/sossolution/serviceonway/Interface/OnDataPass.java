package com.sossolution.serviceonway.Interface;

public interface OnDataPass {

    public void onDataPass(String data);
}
