package com.sossolution.serviceonway.Interface;

public interface OnLoadMoreListener {

    void onLoadMore();
}
