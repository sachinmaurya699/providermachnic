package com.sossolution.serviceonway.Interface;

import com.sossolution.serviceonway.Class.Home_service_details;

public interface My_home_details_interface {


    void my_item(Home_service_details home_service_details);


}
