package com.sossolution.serviceonway.Interface;

public interface DataSender{

    void senddata(String data);

}
