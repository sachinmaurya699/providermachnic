package com.sossolution.serviceonway.Class;

public class Storedata
{

    String text;
    String image;

    public Storedata()
    {

    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
