package com.sossolution.serviceonway.Interface;

public interface InterfaceName
{

    void  hitapimodel(String string);
}
