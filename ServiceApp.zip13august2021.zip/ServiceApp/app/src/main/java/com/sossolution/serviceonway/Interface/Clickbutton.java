package com.sossolution.serviceonway.Interface;

import com.sossolution.serviceonway.Class.Historyitem;

public interface Clickbutton{

    void senddata(Historyitem historyitem);
    void sendid(String historyitem);

}
