package com.sossolution.serviceonway.Interface;

import com.sossolution.serviceonway.Class.Service;

public interface CustomItemService
{

     public void onItemClickService(Service service1);
     public void onItemCheck(String string);
     public   void onItemUncheck(String string);
}
