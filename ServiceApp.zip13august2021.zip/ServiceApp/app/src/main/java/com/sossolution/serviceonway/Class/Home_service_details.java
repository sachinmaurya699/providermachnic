package com.sossolution.serviceonway.Class;

public class Home_service_details
    {
   String  name;
   String phone_number;
   String Emial;
   String Service_type;
   String description;

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getPhone_number()
    {
        return phone_number;
    }

    public void setPhone_number(String phone_number)
    {
        this.phone_number = phone_number;
    }

    public String getEmial()
    {
        return Emial;
    }

    public void setEmial(String emial)
    {
        Emial = emial;
    }

    public String getService_type()
    {
        return Service_type;
    }

    public void setService_type(String service_type)
    {
        Service_type = service_type;
    }

    public String getDescription()
    {
        return description;
    }

    public void setDescription(String description)
    {
        this.description = description;
    }
}

