package com.sossolution.serviceonway.Class;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.sossolution.serviceonway.R;

import java.util.List;

public  class Subscription_adapter  extends RecyclerView.Adapter<Subscription_adapter.My_viewholder>
{
    Context context;
    List<String> list1;

    public Subscription_adapter(Context context, List<String> list1)
    {
        this.context = context;
        this.list1 = list1;
    }


    @NonNull
    @Override
    public My_viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        View view= LayoutInflater.from(context).inflate(R.layout.my_subscription_design,parent,false);
        return new My_viewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Subscription_adapter.My_viewholder holder, int position)
    {

            String text=list1.get(position);
            holder.textView.setText(text);

    }

    @Override
    public int getItemCount()
    {
        return list1.size();
    }

    public class My_viewholder  extends RecyclerView.ViewHolder
    {
        TextView textView;
        public My_viewholder(@NonNull View itemView)
        {

            super(itemView);
            textView=itemView.findViewById(R.id.my_text);
        }
    }
}
