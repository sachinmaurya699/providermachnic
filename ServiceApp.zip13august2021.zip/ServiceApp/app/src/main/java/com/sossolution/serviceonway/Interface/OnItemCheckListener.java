package com.sossolution.serviceonway.Interface;

import android.content.ClipData;

import com.sossolution.serviceonway.Class.Service;

public interface OnItemCheckListener
{

    void onItemCheck(Service service2);
    void onItemUncheck(Service service2);
}
