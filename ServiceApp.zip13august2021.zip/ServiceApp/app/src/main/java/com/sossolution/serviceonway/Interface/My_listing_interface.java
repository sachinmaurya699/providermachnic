package com.sossolution.serviceonway.Interface;

import com.sossolution.serviceonway.Class.Vehicle_listing;

public interface My_listing_interface {

    void my_listing_itm(Vehicle_listing vehicle_listing);
}
