package com.sossolution.serviceonway.Interface;


 public  interface OnFragmentInteractionListener
 {

    void onFragmentInteraction(String msg);

}
