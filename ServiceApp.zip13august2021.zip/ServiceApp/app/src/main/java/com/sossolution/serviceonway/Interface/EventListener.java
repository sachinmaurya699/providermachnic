package com.sossolution.serviceonway.Interface;

public interface EventListener
{

    public void sendDataToActivity(String item);
}
