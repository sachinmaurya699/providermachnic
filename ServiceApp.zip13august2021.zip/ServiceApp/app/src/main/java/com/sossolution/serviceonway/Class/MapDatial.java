package com.sossolution.serviceonway.Class;

public class MapDatial
{
    String servicename;
    String serviceprice;


    public MapDatial() {

    }

    public String getServicename() {
        return servicename;
    }

    public void setServicename(String servicename) {
        this.servicename = servicename;
    }

    public String getServiceprice() {
        return serviceprice;
    }

    public void setServiceprice(String serviceprice)
    {
        this.serviceprice = serviceprice;
    }
}
