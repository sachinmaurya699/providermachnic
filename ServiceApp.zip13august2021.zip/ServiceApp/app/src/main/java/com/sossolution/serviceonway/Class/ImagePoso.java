package com.sossolution.serviceonway.Class;

public class ImagePoso
{

    String Message;

    public String getMessage()
    {
        return Message;
    }
}
