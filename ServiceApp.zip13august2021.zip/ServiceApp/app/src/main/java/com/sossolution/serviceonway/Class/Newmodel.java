package com.sossolution.serviceonway.Class;

public class Newmodel
{
    String model;
    public Newmodel(String model)
    {
        this.model = model;
    }
    public void setModel(String model)
    {
        this.model = model;
    }
    public String getModel() {
        return model;
    }



}
