package com.sossolution.serviceonway.Interface;

import com.sossolution.serviceonway.Class.Shop_item;

public interface Shotingdata
{
    public void item(Shop_item shop_item1);
}
