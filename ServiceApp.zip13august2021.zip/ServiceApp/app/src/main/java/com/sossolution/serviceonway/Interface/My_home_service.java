package com.sossolution.serviceonway.Interface;

import com.sossolution.serviceonway.Class.My_Home_s;

public interface My_home_service
{

     void my_home_service(My_Home_s home_service);

}
