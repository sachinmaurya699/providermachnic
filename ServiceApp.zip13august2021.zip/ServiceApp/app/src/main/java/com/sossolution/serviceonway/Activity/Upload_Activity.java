package com.sossolution.serviceonway.Activity;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.app.DatePickerDialog;
import android.content.ClipData;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Image;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.tabs.TabItem;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.installations.Utils;
import com.sossolution.serviceonway.Class.ImagePoso;
import com.sossolution.serviceonway.Class.Retroclient;
import com.sossolution.serviceonway.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;

public class Upload_Activity extends AppCompatActivity
{

    private TextView show_vechicle,show_maker,show_model;
    private Spinner spinner_fuel,spinner_transmission,spinner_No_owners;
    private  ArrayAdapter<String> adapter;
    private ImageView back;
    private  TextView header;
    private int YEAR,MONTH,DAY;
    private DatePicker picker;
    private DatePickerDialog dialog;
    private Calendar myCalendar;
    private DatePickerDialog dpd;
    private int mYear,mMonth,mDay;
    private SharedPreferences preferences;
    private SharedPreferences.Editor editor;
    private  TabItem tab1;
    private TabLayout tabLayout;
    private Button upload_image;
    private int RESULT_LOAD_IMAGE=1;
    private Bitmap bitmap;
    private  String vechicle;
    private  String maker;
    private String model;
    private Button btn_conform;
    private  TextView textView_des;
    private TextView textView_km;
    private  TextView year1;;
    private TextView textView_price;
    private TextView textView_title;
    String MY_KM,MY_DES,MY_YEAR,MY_TITLE,MY_PRICE;
    //add image
    Bitmap bitmap1;
    View view;
    ByteArrayOutputStream bytearrayoutputstream;
    File file;
    FileOutputStream fileoutputstream;
    int  RESULT_LOAD_IMAGE1=1;
    int REQUEST_CODE_BROWSE_PICTURE;
    private static final String IMAGE_DIRECTORY = "/demonuts";
    private String imageEncoded;
    private List<String> imagesEncodedList;
    private  String message1;
    private Spinner spinner_first,spinner_second,spinner_thired;
    private String encoded;
    private String encoded1;
    private Bitmap decodedImage;
    private  String my_new_url;
    private   String my_image_url;
    private  String  image_item;



    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_vehicle_);

        checkPermission1();

        upload_image=findViewById(R.id.upload_image);

        /*..............spinner cast...............*/
        spinner_fuel=findViewById(R.id.spinner_1);
        spinner_transmission= findViewById(R.id.spinner_2);
        spinner_No_owners= findViewById(R.id.spinner_3);
        textView_km=findViewById(R.id.km);
        textView_price=findViewById(R.id.new_price);
        year1=findViewById(R.id.text_year);
        textView_title=findViewById(R.id.title);
        textView_des=findViewById(R.id.des);

        upload_image.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {

               selectImage();


            }
        });
        //tab1=findViewById(R.id.tab_1);

         preferences=getSharedPreferences("vec",MODE_PRIVATE);
         vechicle=preferences.getString("car","");
         Log.d("vehicle_value",vechicle);

        tabLayout=findViewById(R.id.tabtwo);
        tabLayout.getTabAt(0).setText(vechicle);


        SharedPreferences preferences1 = getSharedPreferences("makeitem", MODE_PRIVATE);
         maker= preferences1.getString("bike","");
        Log.d("vehicle_value",maker);
        tabLayout.getTabAt(1).setText(maker);


        SharedPreferences mPrefs = getSharedPreferences("model1_item", MODE_PRIVATE);
         model= mPrefs.getString("model_1","");
        tabLayout.getTabAt(2).setText(model);
        Log.d("vehicle_value", model);

        btn_conform=findViewById(R.id.conform_form);
        btn_conform.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {

                MY_KM=textView_km.getText().toString();
                MY_YEAR=year1.getText().toString();
                MY_TITLE=textView_title.getText().toString();
                MY_DES=textView_des.getText().toString();
                MY_PRICE=textView_price.getText().toString();

                if(MY_KM.isEmpty())
                {
                    textView_km.setError("Enter the kilometre");
                    textView_km.setFocusable(true);
                }else if(MY_TITLE.isEmpty())
                {
                    textView_title.setError("Enter the  title");
                    textView_title.setFocusable(true);
                }else if(MY_DES.isEmpty())
                {
                    textView_des.setError("Enter the des");
                    textView_des.setFocusable(true);

                }else if(MY_PRICE.isEmpty())
                {
                    textView_price.setError("Enter the price");
                    textView_price.setFocusable(true);
                }else
                {

                    Toast.makeText(Upload_Activity.this, "button click", Toast.LENGTH_SHORT).show();

                    String VEHICLE =vechicle;
                    String MAKER=maker;
                    String MODEL=model;
                    String FUEL=spinner_fuel.getSelectedItem().toString();
                    String TRANSMISSION=spinner_transmission.getSelectedItem().toString();
                    String NUMBER_OF_OWNERS=spinner_No_owners.getSelectedItem().toString();
                    String KM=textView_km.getText().toString();
                    String YEAR=year1.getText().toString();
                    String TITLE=textView_title.getText().toString();
                    String DES=textView_des.getText().toString();
                    String PRICE=textView_price.getText().toString();
                    String IMAGE="data:image/png;base64,"+image_item;


                   //My_listing_details(VEHICLE,MAKER,MODEL,FUEL,TRANSMISSION,NUMBER_OF_OWNERS,KM,YEAR,TITLE,DES,PRICE,IMAGE);

                  //  My_listing_details(IMAGE);


                }


            }
        });



        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);

        year1.setOnClickListener(new View.OnClickListener()
        {

             @Override
             public void onClick(View view)
             {
                 Toast.makeText(Upload_Activity.this, "hello", Toast.LENGTH_SHORT).show();

                 DatePickerDialog dialog= new DatePickerDialog(Upload_Activity.this,android.R.style.Theme_Holo_Dialog, new DatePickerDialog.OnDateSetListener() {
                     @Override    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {

                     //  myCalendar.set(Calendar.YEAR,monthOfYear);




                         Calendar myCalendar = Calendar.getInstance();
                         myCalendar.set(Calendar.YEAR,year);
                         //myCalendar.set(Calendar.MONTH, selectedmonth);
                       //  myCalendar.set(Calendar.DAY_OF_MONTH, selectedday);
                         String myFormat = "yyyy"; //Change as you need
                         SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.FRANCE);
                         year1.setText(sdf.format(myCalendar.getTime()));




                     }
                 }, mYear, mMonth, mDay);

                 dialog.getDatePicker().findViewById(getResources().getIdentifier("day","id","android")).setVisibility(View.GONE);
                 dialog.getDatePicker().findViewById(Resources.getSystem().getIdentifier("month", "id", "android")).setVisibility(View.GONE);
                 dialog.show();


             }
         });

        back=findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        header=findViewById(R.id.header);
        header.setText("UPLOAD VEHICLE FORM ");


        String fuel[]={"SELECT FUEL","CNG&HYBRID","DIESEL","PETROL","ELECTRIC","LPG"};

        String transmission[]={"SELECT TRANSMISSION","AUTOMATIC","MANUAL"};

        String No_of_owners[]={"SELECT NO_OF OWNERS","1","2","3","4","MORE THEN FOUR"};

        adapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,fuel);
        spinner_fuel.setAdapter(adapter);

        adapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,transmission);
        spinner_transmission.setAdapter(adapter);

        adapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,No_of_owners);
        spinner_No_owners.setAdapter(adapter);

    }
   /* private void My_listing_details(String vehicle,String maker,String model,String fuel,String transmission,String number_of_owners,String km,String year, String title,String des,String price,String file)
    {*/

    private void My_listing_details(String file)
    {

        String url3="https://www.serviceonway.com/insert_vehicle_listing_api?file="+file;
       Log.d("my_data",url3);
        //String url3="https://serviceonway.com/insert_vehicle_listing_api?vehicle="+vehicle+"&maker="+maker+"&model="+model+"&fuel="+fuel+"&transmission="+transmission+"&number_of_owners="+number_of_owners+"&km="+km+"&year="+year+"&title="+title+"&des="+des+"&price="+price+"&file="+file;

        StringRequest request= new StringRequest(Request.Method.POST,url3, new Response.Listener<String>()
        {

            @Override
            public void onResponse(String response)
            {

                Toast.makeText(Upload_Activity.this,response+"submit", Toast.LENGTH_SHORT).show();
                 message1 =response;

                if(message1.equals("success"))
                {
                    Log.d("message",message1.toString());
                    Toast.makeText(Upload_Activity.this, "submit detials", Toast.LENGTH_SHORT).show();

                    //Toast.makeText(Upload_Activity.this, "submit all details", Toast.LENGTH_SHORT).show();
                    Intent intent= new Intent(Upload_Activity.this,MainActivity.class);
                    startActivity(intent);

                }else
                {
                    Toast.makeText(Upload_Activity.this, "not submit", Toast.LENGTH_SHORT).show();
                }


            }
        }, new Response.ErrorListener()
        {
            @Override
            public void onErrorResponse(VolleyError error)
            {
                 Log.d("error",error.toString());
                int  statusCode = error.networkResponse.statusCode;
                NetworkResponse response = error.networkResponse;

                Log.d("testerror",""+statusCode+" "+response.data);

            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError
            {
                HashMap<String,String>  hashMap = new HashMap<String, String>();
                hashMap.put ("Content-Type","application/json; charset=utf-8");
              //  hashMap.put("Authorization", "Bearer " + Utils.readSharedSetting(context, "access_token", ""));
                return hashMap;

            }

        };
        //first timeout
        request.setRetryPolicy(new DefaultRetryPolicy(
                DefaultRetryPolicy.DEFAULT_TIMEOUT_MS * 48,
                2,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        request.setShouldCache(false);
        Volley.newRequestQueue(Upload_Activity.this).add(request);



     /*   request.setRetryPolicy(new DefaultRetryPolicy(8000, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        // Adding request to request queue
        request.setShouldCache(false);
        Volley.newRequestQueue(Upload_Activity.this).add(request);*/






        //second time out
     /*   request.setRetryPolicy(new DefaultRetryPolicy(
                1000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        request.setShouldCache(false);
        Volley.newRequestQueue(Upload_Activity.this).add(request);
*/


    }

    public void selectImage()
    {

        galleryintent();

    }

    private boolean checkPermission1()
    {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
        {

            if(ContextCompat.checkSelfPermission(Upload_Activity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE)== PackageManager.PERMISSION_GRANTED)
            {
                Toast.makeText(Upload_Activity.this, "permission grant", Toast.LENGTH_SHORT).show();
            }
            else
            {
                requeststoresepermission();
            }

        }
        return true;


    }

    private void requeststoresepermission()
    {


        if(ActivityCompat.shouldShowRequestPermissionRationale(this,Manifest.permission.READ_EXTERNAL_STORAGE))
        {

        }else
        {
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},1);
        }

    }

    private void cameraIntent()
    {

        Intent intent= new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent,1);

    }

    public void galleryintent()
    {

      /*  Intent pickIntent = new Intent(Intent.ACTION_PICK,
                android.provider.MediaStore.Images.Media.INTERNAL_CONTENT_URI);
        pickIntent.setType("image/*");
        startActivityForResult(Intent.createChooser(pickIntent, "Select Picture"), PICK_IMAGE);*/



        Intent intent= new Intent(Intent.ACTION_PICK,
                android.provider.MediaStore.Images.Media.INTERNAL_CONTENT_URI);
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.setType("image/*");
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), RESULT_LOAD_IMAGE);


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == RESULT_LOAD_IMAGE && resultCode == RESULT_OK && null != data)
        {
            try {
                // When an Image is picked
                if (requestCode == RESULT_LOAD_IMAGE && resultCode == RESULT_OK && null != data)
                {
                    // Get the Image from data

                    String[] filePathColumn = {MediaStore.Images.Media.DATA};
                    imagesEncodedList = new ArrayList<String>();
                    if (data.getData() != null)
                    {

                        Uri mImageUri = data.getData();

                        try {
                             bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), mImageUri);
                            String path = saveImage(bitmap);

                            Toast.makeText(Upload_Activity.this, "Image Saved!", Toast.LENGTH_SHORT).show();
                            // imageView.setImageBitmap(bitmap);

                        } catch (IOException e) {
                            e.printStackTrace();
                            Toast.makeText(Upload_Activity.this, "Failed!", Toast.LENGTH_SHORT).show();
                        }

                        // Get the cursor
                        Cursor cursor = getContentResolver().query(mImageUri,
                                filePathColumn, null, null, null);
                        // Move to first row
                        cursor.moveToFirst();

                        int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                        imageEncoded = cursor.getString(columnIndex);
                        cursor.close();

                    } else {
                        if (data.getClipData() != null) {
                            ClipData mClipData = data.getClipData();
                            ArrayList<Uri> mArrayUri = new ArrayList<Uri>();

                            for (int i = 0; i < mClipData.getItemCount(); i++)
                            {
                                ClipData.Item item = mClipData.getItemAt(i);
                                Uri uri = item.getUri();
                                //add code
                                try {
                                    bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), uri);
                                    String path = saveImage(bitmap);
                                    Toast.makeText(Upload_Activity.this, "Image Saved!", Toast.LENGTH_SHORT).show();
                                    //imageView.setImageBitmap(bitmap);

                                } catch (IOException e) {
                                    e.printStackTrace();
                                    Toast.makeText(Upload_Activity.this, "Failed!", Toast.LENGTH_SHORT).show();
                                }

                                mArrayUri.add(uri);
                                // Get the cursor
                                Cursor cursor = getContentResolver().query(uri, filePathColumn, null, null, null);
                                // Move to first row
                                cursor.moveToFirst();

                                int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                                imageEncoded = cursor.getString(columnIndex);
                                imagesEncodedList.add(imageEncoded);
                                cursor.close();

                            }
                            Log.v("LOG_TAG", "Selected Images" + mArrayUri.size());
                        }
                    }
                } else {
                    Toast.makeText(this, "You haven't picked Image",
                            Toast.LENGTH_LONG).show();
                }
            } catch (Exception e) {
                Toast.makeText(this, "Something went wrong", Toast.LENGTH_LONG)
                        .show();
            }


        }


    }

    private String saveImage(Bitmap bitmap)
    {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 90, bytes);
        byte[] byteArray = bytes.toByteArray();
        encoded = Base64.encodeToString(byteArray, Base64.NO_WRAP);

         my_image_url=encoded.replace("+","%2B");

         image_item=my_image_url.replaceAll("/","");
         Log.d("get_image_url",my_image_url);

       /*  my_new_url=my_image_url;
         Log.d("my_url",my_new_url);*/


       /* byte[] dataBytes = Base64.getEncoder().encode(data.getBytes());
        dataBytes = Base64.getDecoder().decode(dataBytes);*/


        //decode base64 string to image
       /*  byteArray = Base64.decode(encoded, Base64.DEFAULT);
         decodedImage = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
         Log.d("decode", String.valueOf(decodedImage));*/

        return encoded;
    }

}