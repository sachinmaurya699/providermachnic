package com.sossolution.serviceonway.Class;

public class Vehicle_listing_item
{

    String price;
    String fuel;
    String km;
    String wonner_name;
    String address;

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getFuel() {
        return fuel;
    }

    public void setFuel(String fuel) {
        this.fuel = fuel;
    }

    public String getKm() {
        return km;
    }

    public void setKm(String km) {
        this.km = km;
    }

    public String getWonner_name() {
        return wonner_name;
    }

    public void setWonner_name(String wonner_name) {
        this.wonner_name = wonner_name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}

