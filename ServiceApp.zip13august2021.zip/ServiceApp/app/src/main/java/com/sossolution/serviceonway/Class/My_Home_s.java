package com.sossolution.serviceonway.Class;

public class My_Home_s
{

    String Title;
    String text;

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }


}
