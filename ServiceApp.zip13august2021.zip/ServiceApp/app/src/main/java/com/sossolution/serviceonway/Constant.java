package com.sossolution.serviceonway;

public class Constant {

    public  static  final  String channel_id="Mychannel";
    public static final String name ="Serviceonway";
    public static final String description ="Serviceonway";


}
