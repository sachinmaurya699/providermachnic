package com.sossolution.serviceonway.Interface;

import com.sossolution.serviceonway.Class.Wallet_history;

public   interface Myinterfacehistary
{

    void newitem(Wallet_history wallet_history);

}
