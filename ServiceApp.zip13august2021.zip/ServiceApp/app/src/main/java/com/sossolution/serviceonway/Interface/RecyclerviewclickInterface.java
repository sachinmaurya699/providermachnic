package com.sossolution.serviceonway.Interface;


import com.sossolution.serviceonway.Class.Storedata;

public interface RecyclerviewclickInterface
{

    void onItemClick(Storedata item);

}
