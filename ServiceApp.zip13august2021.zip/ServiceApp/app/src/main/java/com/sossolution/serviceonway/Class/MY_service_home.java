package com.sossolution.serviceonway.Class;

public class MY_service_home {

    String name;
    String des_cription;
    String image;


    public MY_service_home()
    {

    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getDes_cription()
    {
        return des_cription;
    }

    public void setDes_cription(String des_cription)
    {
        this.des_cription = des_cription;
    }

    public String getImage()
    {
        return image;
    }

    public void setImage(String image)
    {
        this.image = image;
    }
}
