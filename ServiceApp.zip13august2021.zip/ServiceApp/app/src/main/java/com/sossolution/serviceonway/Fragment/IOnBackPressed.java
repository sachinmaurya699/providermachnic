package com.sossolution.serviceonway.Fragment;

public interface IOnBackPressed {

    boolean onBackPressed();

}
