package com.sossolution.serviceonway.Interface;

import android.view.View;

public interface RecyclerviewSelect{

    void onitemClickModel(View v, int position);
}
