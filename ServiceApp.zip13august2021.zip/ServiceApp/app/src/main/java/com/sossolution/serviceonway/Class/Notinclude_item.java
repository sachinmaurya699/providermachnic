package com.sossolution.serviceonway.Class;

public class Notinclude_item
{
   private String Service;

    public String getService()
    {
        return Service;
    }

    public void setService(String service)
    {
        Service = service;
    }
}
