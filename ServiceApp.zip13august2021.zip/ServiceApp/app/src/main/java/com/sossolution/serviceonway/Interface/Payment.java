package com.sossolution.serviceonway.Interface;

interface Payment {
}
