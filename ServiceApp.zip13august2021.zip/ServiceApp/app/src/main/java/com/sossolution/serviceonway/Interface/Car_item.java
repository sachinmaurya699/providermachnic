package com.sossolution.serviceonway.Interface;

import com.sossolution.serviceonway.Class.Vehicle_car_name;

public interface Car_item
{

     void my_car_item(Vehicle_car_name vehicle_car_name);


}
