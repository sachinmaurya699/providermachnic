package com.sossolution.serviceonway.Class;

public class Hero {

    private String name;
    private String realname;
    private String team;
}
