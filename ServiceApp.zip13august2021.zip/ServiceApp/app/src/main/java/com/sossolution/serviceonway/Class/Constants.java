package com.sossolution.serviceonway.Class;

public class Constants{

    public static final String CHANNEL_ID= "my_channel_01";
    public static final String CHANNEL_NAME= "Simplified Coding Notification";
    public static final String CHANNEL_DESCRIPTION= "www.Serviceonway.com";

}
