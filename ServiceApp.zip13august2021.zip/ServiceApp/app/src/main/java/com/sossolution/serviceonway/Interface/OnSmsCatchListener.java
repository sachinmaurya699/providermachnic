package com.sossolution.serviceonway.Interface;

public interface OnSmsCatchListener<T> {

    void onSmsCatch(String message);
}
