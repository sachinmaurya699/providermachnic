package com.sossolution.serviceonway.Interface;

import android.view.View;

public interface CustomItemClickListener
{
    public void onItemClick(View v, int position);
}
