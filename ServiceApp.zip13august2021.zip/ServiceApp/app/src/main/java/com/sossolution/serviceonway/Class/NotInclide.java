package com.sossolution.serviceonway.Class;

public class NotInclide
    {

    String Notincludeservice;

    public NotInclide(String name)
    {

    }

    public String getNotincludeservice()
    {
        return Notincludeservice;
    }

    public void setNotincludeservice
            (String notincludeservice)
    {
        Notincludeservice = notincludeservice;
    }



}
