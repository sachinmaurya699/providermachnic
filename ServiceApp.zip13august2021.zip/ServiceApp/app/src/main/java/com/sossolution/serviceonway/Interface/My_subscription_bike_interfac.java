package com.sossolution.serviceonway.Interface;

import com.razorpay.Subscription;
import com.sossolution.serviceonway.Activity.Subscription_my_item;
import com.sossolution.serviceonway.Class.Wallet_history;

public abstract class My_subscription_bike_interfac {

    public abstract void my_item_subscription(Subscription_my_item my_item);

    // void newitem_subscription(Subscription_my_item my_item);


}
