package com.sossolution.serviceonway.Class;

public class Subscriptn_not_include {

    String text;

    public Subscriptn_not_include()
    {

    }
    public String getText()
    {
        return text;
    }
    public void  setText(String text)
    {
        this.text=text;
    }


}
