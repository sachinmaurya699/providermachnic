package com.sossolution.serviceonway.Class;

public class Notservice{


    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    String service;


    public Notservice() {

    }
}
