package com.sossolution.serviceonway.Interface;

import com.sossolution.serviceonway.Class.MY_service_home;

public interface My_home_interface
{
    void item_service(MY_service_home service_home);

}
