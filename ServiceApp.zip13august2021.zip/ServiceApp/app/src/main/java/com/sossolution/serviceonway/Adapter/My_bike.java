package com.sossolution.serviceonway.Adapter;

import com.sossolution.serviceonway.Class.Vehicle_bike_name;
import com.sossolution.serviceonway.Class.Vehicle_name;

public interface My_bike
{

    void mybike_item(Vehicle_bike_name vehicle_bike_name1);

}
