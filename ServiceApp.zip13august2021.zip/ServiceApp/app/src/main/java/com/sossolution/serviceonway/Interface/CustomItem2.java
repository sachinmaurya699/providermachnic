package com.sossolution.serviceonway.Interface;

import com.sossolution.serviceonway.Class.Newmodel;

public interface CustomItem2 {

    public void onItem(Newmodel newmodel);
}
