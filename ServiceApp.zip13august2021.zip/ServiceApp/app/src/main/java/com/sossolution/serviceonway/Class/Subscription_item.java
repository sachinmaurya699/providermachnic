package com.sossolution.serviceonway.Class;

 public class Subscription_item
 {

     String text;

     public Subscription_item()
     {

     }
     public String getText()

     {
         return text;
     }
     public  void setText(String text1)
     {
         this.text= text1;
     }


}
